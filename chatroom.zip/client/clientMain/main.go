package main

import "happiness999.cn/chatroom/client/process"

func main() {
	st := process.ShowTable{}
	st.MainInterface()
}
